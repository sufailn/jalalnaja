import React, { useState } from 'react';
import { initialWeddingData } from './data/weddingConfig';
import { OpeningEnvelope } from './components/OpeningEnvelope';
import { HeroSection } from './components/HeroSection';
import { InvitationCard } from './components/InvitationCard';
import { FamilySection } from './components/FamilySection';
import { WeddingDetails } from './components/WeddingDetails';
import { LovedOnes } from './components/LovedOnes';
import { ClosingSection } from './components/ClosingSection';
import { ambientAudio } from './utils/ambientAudio';
import { Volume2, VolumeX } from 'lucide-react';

export default function App() {
  const [weddingData] = useState(initialWeddingData);
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  const handleScrollToHero = () => {
    const heroEl = document.getElementById('hero');
    if (heroEl) {
      heroEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleToggleMusic = () => {
    const status = ambientAudio.toggle();
    setIsPlayingMusic(status);
  };

  return (
    <div className="relative min-h-screen bg-[#F4F0E6] text-[#37352F] selection:bg-[#414B2E] selection:text-[#F4F0E6]">
      {/* Floating Ambient Music Medallion (Unobtrusive & Elegant) */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={handleToggleMusic}
          title={isPlayingMusic ? 'Mute Background Ambience' : 'Play Background Ambience'}
          className={`group flex items-center gap-2.5 p-3 sm:px-4 sm:py-2.5 rounded-full border border-[#B59A65]/50 shadow-lg backdrop-blur-md transition-all duration-300 cursor-pointer ${
            isPlayingMusic
              ? 'bg-[#414B2E] text-[#F4F0E6] shadow-[0_4px_20px_rgba(65,75,46,0.4)]'
              : 'bg-[#F4F0E6]/90 text-[#414B2E] hover:bg-[#E9E1D1]'
          }`}
          aria-label="Toggle ambient sitar and harp music"
        >
          {isPlayingMusic ? (
            <Volume2 className="w-4 h-4 text-[#B59A65] animate-pulse" />
          ) : (
            <VolumeX className="w-4 h-4 text-[#899477]" />
          )}
          <span className="hidden sm:inline font-cinzel text-[11px] tracking-widest uppercase font-medium">
            {isPlayingMusic ? 'Sound On' : 'Play Music'}
          </span>
        </button>
      </div>

      <main className="w-full">
        {/* SECTION 01: Interactive Opening Experience */}
        <OpeningEnvelope
          weddingData={weddingData}
          isOpen={isEnvelopeOpen}
          onOpen={() => setIsEnvelopeOpen(true)}
          onScrollToContent={handleScrollToHero}
        />

        {/* SECTION 02: Hero Section */}
        <HeroSection weddingData={weddingData} />

        {/* SECTION 03: Printed Wedding Invitation Card */}
        <InvitationCard weddingData={weddingData} />

        {/* SECTION 04: Two-Column Family Lineage Section */}
        <FamilySection weddingData={weddingData} />

        {/* SECTION 05: Wedding Details & Live Countdown */}
        <WeddingDetails weddingData={weddingData} />

        {/* SECTION 06: Loved Ones & Sisters */}
        <LovedOnes sisters={weddingData.sisters} />

        {/* SECTION 07: Memorable Closing Section */}
        <ClosingSection
          weddingData={weddingData}
          onReopenEnvelope={() => setIsEnvelopeOpen(false)}
        />
      </main>
    </div>
  );
}
