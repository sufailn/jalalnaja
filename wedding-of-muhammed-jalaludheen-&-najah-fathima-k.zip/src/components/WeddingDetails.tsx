import React, { useState } from 'react';
import { WeddingData } from '../data/weddingConfig';
import { CountdownTimer } from './CountdownTimer';
import { CornerOrnament, MughalArchMotif, OrnamentalDivider, BackgroundBotanicals } from './FloralDecorations';
import { Calendar, Clock, MapPin, Navigation, CalendarPlus, Check, ExternalLink } from 'lucide-react';

interface WeddingDetailsProps {
  weddingData: WeddingData;
}

export const WeddingDetails: React.FC<WeddingDetailsProps> = ({ weddingData }) => {
  const { details, groom, bride } = weddingData;
  const [calendarSaved, setCalendarSaved] = useState(false);

  // Generate iCalendar (.ics) download for confirmed date: 24th Dec 2026, 4:00 PM
  const handleDownloadIcs = () => {
    const title = `Wedding: ${groom.name} & ${bride.name}`;
    const description = `Wedding celebration of ${groom.name} and ${bride.name}. Wording: ${weddingData.wording.subtitle}`;
    const location = `Google Maps: ${details.googleMapsUrl}`;

    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Jalaludheen & Najah Wedding//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      'BEGIN:VEVENT',
      `SUMMARY:${title}`,
      `DESCRIPTION:${description}`,
      `LOCATION:${location}`,
      'DTSTART:20261224T103000Z', // 4:00 PM IST is 10:30 UTC
      'DTEND:20261224T153000Z',
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Wedding-Jalaludheen-Najah.ics');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setCalendarSaved(true);
    setTimeout(() => setCalendarSaved(false), 4000);
  };

  // Google Calendar direct URL
  const getGoogleCalendarUrl = () => {
    const title = encodeURIComponent(`Wedding: ${groom.name} & ${bride.name}`);
    const detailsText = encodeURIComponent(
      `Wedding celebration of ${groom.name} and ${bride.name}. Map Location: ${details.googleMapsUrl}`
    );
    const locationText = encodeURIComponent(details.googleMapsUrl);
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&details=${detailsText}&location=${locationText}&dates=20261224T160000/20261224T210000`;
  };

  return (
    <section id="details" className="relative py-28 px-4 bg-[#F4F0E6] paper-grain overflow-hidden">
      {/* Living Background Botanical Ornaments with Graceful Pulse */}
      <BackgroundBotanicals variant="light" />
      <div className="max-w-4xl mx-auto">
        
        {/* Section Heading with Arch */}
        <div className="text-center mb-16">
          <MughalArchMotif className="w-28 h-12 text-[#899477] mx-auto opacity-75 mb-3" />
          <span className="editorial-kicker text-xs text-[#414B2E] font-semibold">
            Wedding Itinerary &amp; Venue
          </span>
          <h2 className="editorial-h1 text-3xl sm:text-4xl md:text-5xl text-[#35432B] mt-2 font-normal">
            The Auspicious Occasion
          </h2>
          <div className="w-16 h-[1px] bg-[#B59A65] mx-auto mt-4" />
          <p className="editorial-quote text-sm sm:text-base text-[#37352F]/80 max-w-md mx-auto mt-3">
            In the presence of loved ones, united in prayer and eternal companionship.
          </p>
        </div>

        {/* Live Countdown Timer directly to 24th December 2026, 04:00 PM */}
        <div className="mb-14">
          <CountdownTimer targetDate={details.date} targetTime="16:00:00" />
        </div>

        {/* Main Event Showcase Card */}
        <div className="relative bg-[#E9E1D1]/70 p-8 sm:p-14 rounded-sm border border-[#B59A65]/50 shadow-md paper-grain-cream">
          {/* Inner hairline */}
          <div className="absolute inset-3 border border-[#414B2E]/20 pointer-events-none rounded-xs" />

          {/* Corners */}
          <CornerOrnament className="absolute top-3 left-3 w-8 h-8 text-[#B59A65]" />
          <CornerOrnament className="absolute top-3 right-3 w-8 h-8 text-[#B59A65] -scale-x-100" />
          <CornerOrnament className="absolute bottom-3 left-3 w-8 h-8 text-[#B59A65] -scale-y-100" />
          <CornerOrnament className="absolute bottom-3 right-3 w-8 h-8 text-[#B59A65] -scale-100" />

          {/* 3 Core Highlight Blocks */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center relative z-10">
            
            {/* Block 1: Date */}
            <div className="p-6 bg-[#F4F0E6] rounded border border-[#B59A65]/35 flex flex-col items-center">
              <div className="w-11 h-11 rounded-full bg-[#414B2E] text-[#B59A65] flex items-center justify-center mb-3 shadow-xs">
                <Calendar className="w-5 h-5 text-[#B59A65]" />
              </div>
              <span className="editorial-kicker text-[11px] text-[#899477] font-semibold">
                Wedding Day
              </span>
              <p className="editorial-h2 text-xl sm:text-2xl text-[#414B2E] font-medium mt-1">
                {details.dateDisplay}
              </p>
              <p className="editorial-quote text-sm text-[#542D3A] mt-0.5">
                {details.day}
              </p>
            </div>

            {/* Block 2: Time */}
            <div className="p-6 bg-[#F4F0E6] rounded border border-[#B59A65]/35 flex flex-col items-center">
              <div className="w-11 h-11 rounded-full bg-[#414B2E] text-[#B59A65] flex items-center justify-center mb-3 shadow-xs">
                <Clock className="w-5 h-5 text-[#B59A65]" />
              </div>
              <span className="editorial-kicker text-[11px] text-[#899477] font-semibold">
                Ceremony Time
              </span>
              <p className="editorial-h2 text-xl sm:text-2xl text-[#414B2E] font-medium mt-1">
                {details.time}
              </p>
              <p className="editorial-quote text-sm text-[#542D3A] mt-0.5">
                Auspicious Evening
              </p>
            </div>

            {/* Block 3: Location / Google Maps */}
            <div className="p-6 bg-[#F4F0E6] rounded border border-[#B59A65]/35 flex flex-col items-center">
              <div className="w-11 h-11 rounded-full bg-[#542D3A] text-[#F4F0E6] flex items-center justify-center mb-3 shadow-xs">
                <MapPin className="w-5 h-5 text-[#B59A65]" />
              </div>
              <span className="editorial-kicker text-[11px] text-[#899477] font-semibold">
                Venue Location
              </span>
              <p className="editorial-h2 text-lg sm:text-xl text-[#414B2E] font-medium mt-1">
                Directions Provided
              </p>
              <a
                href={details.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="editorial-quote text-xs text-[#542D3A] hover:underline mt-0.5 inline-flex items-center gap-1"
              >
                <span>Open Google Maps</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

          </div>

          <div className="my-8">
            <OrnamentalDivider className="text-[#B59A65] mx-auto max-w-sm" />
          </div>

          {/* Action CTAs: Direct Maps Directions + Add to Calendar */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
            {/* Primary Google Maps Navigation Link */}
            <a
              href={details.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-7 py-3.5 bg-[#414B2E] hover:bg-[#35432B] text-[#F4F0E6] font-cinzel text-xs tracking-[0.2em] uppercase rounded-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer group"
            >
              <Navigation className="w-4 h-4 text-[#B59A65] group-hover:scale-110 transition-transform" />
              <span>Get Google Maps Directions</span>
            </a>

            {/* Add to Calendar (.ics) */}
            <button
              onClick={handleDownloadIcs}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#E9E1D1] hover:bg-[#F4F0E6] text-[#414B2E] border border-[#B59A65]/60 font-cinzel text-xs tracking-[0.2em] uppercase rounded-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {calendarSaved ? (
                <>
                  <Check className="w-4 h-4 text-emerald-700" />
                  <span>Calendar File Saved!</span>
                </>
              ) : (
                <>
                  <CalendarPlus className="w-4 h-4 text-[#B59A65]" />
                  <span>Save to Calendar (.ics)</span>
                </>
              )}
            </button>

            {/* Direct Google Calendar Web Link */}
            <a
              href={getGoogleCalendarUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 bg-[#542D3A] hover:bg-[#43232e] text-[#F4F0E6] font-cinzel text-xs tracking-[0.2em] uppercase rounded-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-[#B59A65]" />
              <span>Google Calendar</span>
            </a>
          </div>

          {/* Helpful Venue Note */}
          <p className="font-serif italic text-xs text-center text-[#899477] mt-8">
            Click the directions button above for live GPS turn-by-turn navigation directly to the celebration.
          </p>
        </div>

      </div>
    </section>
  );
};
