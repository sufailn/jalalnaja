import React, { useState, useRef, useEffect } from 'react';
import gsap from 'gsap';
import { WeddingData } from '../data/weddingConfig';
import { CornerOrnament, MughalArchMotif, OliveBranch, WaxSealEmblem } from './FloralDecorations';
import confetti from 'canvas-confetti';
import { ChevronDown, Sparkles, Volume2, VolumeX, Mail } from 'lucide-react';

interface OpeningEnvelopeProps {
  weddingData: WeddingData;
  isOpen: boolean;
  onOpen: () => void;
  onScrollToContent: () => void;
}

export const OpeningEnvelope: React.FC<OpeningEnvelopeProps> = ({
  weddingData,
  isOpen,
  onOpen,
  onScrollToContent,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const envelopeFlapRef = useRef<HTMLDivElement>(null);
  const waxSealRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const contentFadeRef = useRef<HTMLDivElement>(null);
  const [hasInteracted, setHasInteracted] = useState(false);

  // Gentle entry animation on mount
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.envelope-wrapper',
        { opacity: 0, y: 30, scale: 0.94 },
        { opacity: 1, y: 0, scale: 1, duration: 1.4, ease: 'power2.out' }
      );
      gsap.fromTo(
        '.envelope-hint',
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 1, delay: 0.8, ease: 'power2.out' }
      );
      gsap.to('.wax-seal-pulse', {
        scale: 1.05,
        repeat: -1,
        yoyo: true,
        duration: 1.8,
        ease: 'sine.inOut',
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const handleOpenEnvelope = () => {
    if (isOpen) {
      onScrollToContent();
      return;
    }

    setHasInteracted(true);
    onOpen();

    // Trigger subtle gold & ivory paper celebration
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#B59A65', '#E9E1D1', '#414B2E', '#F4F0E6'],
        disableForReducedMotion: true,
      });
    } catch {
      // safe fallback
    }

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        defaults: { ease: 'power3.inOut' },
      });

      // 1. Wax seal lifts & fades slightly
      tl.to(waxSealRef.current, {
        scale: 1.25,
        opacity: 0,
        y: -25,
        duration: 0.45,
      })
      // 2. Flap unfolds upward
      .to(
        envelopeFlapRef.current,
        {
          rotateX: 180,
          duration: 0.85,
          transformOrigin: 'top center',
          ease: 'power2.inOut',
        },
        '-=0.2'
      )
      // 3. Card emerges out of envelope
      .to(
        cardRef.current,
        {
          y: -180,
          scale: 1.03,
          duration: 1.1,
          ease: 'power3.out',
        },
        '-=0.4'
      )
      // 4. Fade in full card details
      .to(
        contentFadeRef.current,
        {
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
        },
        '-=0.6'
      );
    }, containerRef);
  };

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen w-full flex flex-col items-center justify-center px-4 py-12 paper-grain overflow-hidden"
    >
      {/* Decorative vertical botanical pinstripe backdrop hint inspired by Reference 2 */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#414b2e_1px,transparent_1px)] [background-size:24px_24px]" />

      {/* Subtle top header badge */}
      <div className="z-10 text-center mb-8">
        <p className="font-cinzel text-xs tracking-[0.3em] uppercase text-[#414B2E]/80 mb-2">
          Wedding Announcement
        </p>
        <p className="font-arabic text-2xl text-[#414B2E] tracking-wide mb-1">
          {weddingData.wording.basmala}
        </p>
        <p className="font-serif italic text-sm text-[#899477]">
          {weddingData.wording.basmalaTranslation}
        </p>
      </div>

      {/* Main Envelope Presentation Container */}
      <div className="envelope-wrapper relative z-20 w-full max-w-[540px] aspect-[1.38/1] perspective-1000 select-none">
        {/* Envelope Shell Container */}
        <div className="relative w-full h-full shadow-[0_25px_60px_-15px_rgba(53,67,43,0.35)] rounded-md overflow-visible">
          
          {/* Back Liner (Inside of Envelope when opened - Landscape artwork from Reference 1) */}
          <div className="absolute inset-0 bg-[#35432B] rounded-md overflow-hidden">
            <div
              className="absolute inset-0 opacity-80 bg-cover bg-center"
              style={{
                backgroundImage: `url('/assets/aistudio/WhatsApp_Image_2026-10-31_at_2.30.27_PM_db2cc7b0.jpeg')`,
                backgroundSize: '180%',
                backgroundPosition: 'center 20%',
                filter: 'sepia(0.2) contrast(1.05)',
              }}
            />
            {/* Subtle vintage gold rim */}
            <div className="absolute inset-0 border border-[#B59A65]/40 rounded-md" />
          </div>

          {/* Emerging Invitation Card Inside Envelope */}
          <div
            ref={cardRef}
            className="absolute left-4 right-4 top-4 bottom-4 bg-[#F4F0E6] rounded border border-[#B59A65]/50 shadow-2xl transition-transform flex flex-col items-center justify-center p-6 text-center z-10 paper-grain"
            style={{
              transform: isOpen ? 'translateY(-180px) scale(1.03)' : 'translateY(0px)',
              boxShadow: '0 15px 35px rgba(0,0,0,0.2)',
            }}
          >
            {/* Double decorative border */}
            <div className="absolute inset-2 border border-[#B59A65]/40 pointer-events-none rounded-sm" />
            <div className="absolute inset-3 border border-[#414B2E]/20 pointer-events-none rounded-sm" />

            <CornerOrnament className="absolute top-3 left-3 w-7 h-7 text-[#B59A65]" />
            <CornerOrnament className="absolute top-3 right-3 w-7 h-7 text-[#B59A65] -scale-x-100" />
            <CornerOrnament className="absolute bottom-3 left-3 w-7 h-7 text-[#B59A65] -scale-y-100" />
            <CornerOrnament className="absolute bottom-3 right-3 w-7 h-7 text-[#B59A65] -scale-100" />

            <div ref={contentFadeRef} className="w-full flex flex-col items-center justify-center py-2">
              {/* Couple's Calligraphy Monogram Logo */}
              <div className="w-16 h-22 sm:w-20 sm:h-26 mb-1 flex items-center justify-center">
                <img
                  src="/assets/aistudio/logo_cropped_olive.png"
                  alt="Jalaludheen & Najah Monogram"
                  className="w-full h-full object-contain drop-shadow-xs"
                />
              </div>

              <span className="font-cinzel text-[9px] sm:text-[10px] tracking-[0.25em] uppercase text-[#414B2E] mb-0.5">
                The Blessed Union Of
              </span>

              <h2 className="font-script text-2xl sm:text-4xl text-[#414B2E] leading-tight my-0.5 gold-foil-text font-bold">
                {weddingData.groom.name}
              </h2>

              <div className="flex items-center gap-2 my-0.5">
                <div className="h-[1px] w-6 bg-[#B59A65]/60" />
                <span className="font-serif italic text-base text-[#542D3A] font-medium">&amp;</span>
                <div className="h-[1px] w-6 bg-[#B59A65]/60" />
              </div>

              <h2 className="font-script text-2xl sm:text-4xl text-[#414B2E] leading-tight my-0.5 gold-foil-text font-bold">
                {weddingData.bride.name}
              </h2>

              <div className="flex items-center gap-2 mt-2 pt-2 border-t border-[#B59A65]/30">
                <span className="font-cinzel text-[10px] sm:text-xs tracking-[0.2em] uppercase text-[#414B2E] font-medium">
                  {weddingData.details.dateDisplay} · {weddingData.details.time}
                </span>
              </div>

              {isOpen && (
                <button
                  onClick={onScrollToContent}
                  className="mt-3 px-5 py-1.5 bg-[#414B2E] hover:bg-[#35432B] text-[#F4F0E6] text-[11px] font-cinzel tracking-widest uppercase rounded shadow transition-all duration-200 flex items-center gap-2 group cursor-pointer"
                >
                  <span>Enter Invitation</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
                </button>
              )}
            </div>
          </div>

          {/* Front Pocket of Envelope (Deep Olive Paper with Texture) */}
          <div className="absolute inset-0 z-20 pointer-events-none">
            {/* Left flap triangle */}
            <div
              className="absolute inset-0 bg-[#35432B]"
              style={{
                clipPath: 'polygon(0% 0%, 50% 50%, 0% 100%)',
                boxShadow: 'inset 0 0 25px rgba(0,0,0,0.3)',
              }}
            />
            {/* Right flap triangle */}
            <div
              className="absolute inset-0 bg-[#3D4C2F]"
              style={{
                clipPath: 'polygon(100% 0%, 50% 50%, 100% 100%)',
                boxShadow: 'inset 0 0 25px rgba(0,0,0,0.3)',
              }}
            />
            {/* Bottom flap triangle */}
            <div
              className="absolute inset-0 bg-[#414B2E]"
              style={{
                clipPath: 'polygon(0% 100%, 50% 48%, 100% 100%)',
                boxShadow: '0 -4px 15px rgba(0,0,0,0.25)',
              }}
            >
              {/* Subtle gold line along bottom flap rim */}
              <div
                className="absolute inset-0 border-t border-[#B59A65]/30 pointer-events-none"
                style={{
                  clipPath: 'polygon(0% 100%, 50% 48%, 100% 100%)',
                }}
              />
            </div>
          </div>

          {/* Top Flap with 3D Flip */}
          <div
            ref={envelopeFlapRef}
            className="absolute top-0 left-0 right-0 h-1/2 z-30 preserve-3d"
            style={{
              transformOrigin: 'top center',
              transform: isOpen ? 'rotateX(180deg)' : 'rotateX(0deg)',
              pointerEvents: isOpen ? 'none' : 'auto',
            }}
          >
            {/* Outside of Top Flap */}
            <div
              className="absolute inset-0 bg-[#414B2E] shadow-lg flex items-end justify-center pb-2 cursor-pointer"
              style={{
                clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%)',
                backfaceVisibility: 'hidden',
              }}
              onClick={handleOpenEnvelope}
            >
              {/* Gold foil hairline along flap angle */}
              <svg className="w-full h-full absolute inset-0 pointer-events-none" viewBox="0 0 100 50" preserveAspectRatio="none">
                <line x1="0" y1="0" x2="50" y2="100" stroke="#B59A65" strokeWidth="0.5" strokeOpacity="0.5" />
                <line x1="100" y1="0" x2="50" y2="100" stroke="#B59A65" strokeWidth="0.5" strokeOpacity="0.5" />
              </svg>
            </div>

            {/* Inside of Top Flap (Revealed when opened) */}
            <div
              className="absolute inset-0 bg-[#35432B]"
              style={{
                clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%)',
                transform: 'rotateX(180deg)',
                backfaceVisibility: 'hidden',
              }}
            >
              <div
                className="absolute inset-0 opacity-70 bg-cover bg-center"
                style={{
                  backgroundImage: `url('/assets/aistudio/WhatsApp_Image_2026-10-31_at_2.30.27_PM_db2cc7b0.jpeg')`,
                  backgroundSize: '150%',
                  backgroundPosition: 'center top',
                }}
              />
            </div>
          </div>

          {/* Wax Seal placed at the center of the flap meeting point */}
          {!isOpen && (
            <div
              ref={waxSealRef}
              className="wax-seal-pulse absolute top-[48%] left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 cursor-pointer"
              onClick={handleOpenEnvelope}
              title="Click to Open Invitation"
            >
              <WaxSealEmblem
                monogram="M & N"
                variant="burgundy"
                size="md"
              />
            </div>
          )}
        </div>
      </div>

      {/* Interactive Helper Text */}
      <div className="envelope-hint relative z-20 mt-10 text-center">
        {!isOpen ? (
          <button
            onClick={handleOpenEnvelope}
            className="group inline-flex items-center gap-2 px-6 py-2.5 bg-[#414B2E] text-[#F4F0E6] font-cinzel text-xs tracking-[0.2em] uppercase rounded-full shadow-md hover:bg-[#35432B] hover:shadow-lg transition-all duration-300 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B59A65] group-hover:rotate-12 transition-transform" />
            <span>Click Seal to Open Invitation</span>
          </button>
        ) : (
          <button
            onClick={onScrollToContent}
            className="group inline-flex items-center gap-2 px-6 py-2.5 bg-[#E9E1D1] text-[#414B2E] border border-[#B59A65]/40 font-cinzel text-xs tracking-[0.2em] uppercase rounded-full shadow-sm hover:bg-[#F4F0E6] transition-all duration-300 cursor-pointer"
          >
            <span>Scroll to Experience</span>
            <ChevronDown className="w-3.5 h-3.5 group-hover:translate-y-1 transition-transform" />
          </button>
        )}
        <p className="font-serif italic text-xs text-[#899477] mt-3">
          A bespoke digital stationery experience
        </p>
      </div>
    </section>
  );
};
