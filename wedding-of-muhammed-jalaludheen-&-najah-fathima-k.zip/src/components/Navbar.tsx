import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Mail } from 'lucide-react';

interface NavbarProps {
  onOpenEnvelope: () => void;
  isPlayingMusic: boolean;
  onToggleMusic: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenEnvelope,
  isPlayingMusic,
  onToggleMusic,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#F4F0E6]/95 backdrop-blur-md border-b border-[#B59A65]/30 shadow-xs py-3'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a
          href="#hero"
          className="font-script text-2xl sm:text-3xl text-[#414B2E] hover:text-[#35432B] transition-colors whitespace-nowrap shrink-0 tracking-wide font-bold"
        >
          Jalaludheen & Najah
        </a>

        {/* Zone 2: 4-5 single-line clean navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-cinzel tracking-[0.18em] uppercase text-[#414B2E]/90">
          <a
            href="#hero"
            className="hover:text-[#B59A65] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#B59A65]"
          >
            The Union
          </a>
          <a
            href="#invitation"
            className="hover:text-[#B59A65] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#B59A65]"
          >
            Invitation
          </a>
          <a
            href="#families"
            className="hover:text-[#B59A65] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#B59A65]"
          >
            Families
          </a>
          <a
            href="#details"
            className="hover:text-[#B59A65] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#B59A65]"
          >
            Details
          </a>
          <a
            href="#rsvp"
            className="hover:text-[#B59A65] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#B59A65]"
          >
            RSVP
          </a>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleMusic}
            title={isPlayingMusic ? 'Mute Ambient Music' : 'Play Ambient Music'}
            className="p-2 rounded-full border border-[#B59A65]/40 text-[#414B2E] hover:bg-[#E9E1D1] transition-colors cursor-pointer"
            aria-label="Toggle ambient sound"
          >
            {isPlayingMusic ? (
              <Volume2 className="w-4 h-4 text-[#414B2E]" />
            ) : (
              <VolumeX className="w-4 h-4 text-[#899477]" />
            )}
          </button>

          <a
            href="#rsvp"
            className="px-4 py-2 text-xs font-cinzel tracking-widest uppercase text-[#F4F0E6] bg-[#414B2E] hover:bg-[#35432B] rounded-sm transition-colors whitespace-nowrap shrink-0 shadow-xs cursor-pointer"
          >
            RSVP
          </a>
        </div>
      </div>
    </header>
  );
};
