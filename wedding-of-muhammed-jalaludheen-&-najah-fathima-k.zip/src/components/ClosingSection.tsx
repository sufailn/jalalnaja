import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { WeddingData } from '../data/weddingConfig';
import { MughalArchMotif, OliveBranch, OrnamentalDivider, WaxSealEmblem } from './FloralDecorations';
import { ArrowUp, Mail, Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ClosingSectionProps {
  weddingData: WeddingData;
  onReopenEnvelope: () => void;
}

export const ClosingSection: React.FC<ClosingSectionProps> = ({
  weddingData,
  onReopenEnvelope,
}) => {
  const containerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.closing-fade',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          stagger: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top 75%',
          },
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      ref={containerRef}
      className="relative min-h-[85vh] py-28 px-4 bg-[#414B2E] text-[#F4F0E6] flex flex-col items-center justify-center text-center overflow-hidden"
    >
      {/* Background Texture from Reference 3 (dark olive paper with repeated golden dot motifs) */}
      <div
        className="absolute inset-0 opacity-25 pointer-events-none"
        style={{
          backgroundImage: `url('/assets/aistudio/WhatsApp_Image_2026-10-31_at_2.30.28_PM_dbef1546.jpeg')`,
          backgroundSize: '280px auto',
        }}
      />

      <div className="relative z-10 max-w-2xl mx-auto flex flex-col items-center">
        {/* Crest & Calligraphy Logo */}
        <div className="closing-fade mb-6 flex flex-col items-center">
          <div className="w-24 h-36 sm:w-28 sm:h-44 mb-3 flex items-center justify-center">
            <img
              src="/assets/aistudio/logo_cropped_gold.png"
              alt="Jalaludheen & Najah Monogram"
              className="w-full h-full object-contain drop-shadow-[0_4px_16px_rgba(181,154,101,0.4)]"
            />
          </div>
          <MughalArchMotif className="w-36 h-14 text-[#B59A65] mx-auto opacity-75" />
        </div>

        {/* Heartfelt closing gratitude quote */}
        <div className="closing-fade">
          <p className="editorial-quote text-lg sm:text-2xl text-[#F4F0E6] max-w-xl mx-auto font-light leading-[1.6]">
            &ldquo;{weddingData.wording.closingGratitude}&rdquo;
          </p>
        </div>

        <div className="closing-fade my-8">
          <OrnamentalDivider className="text-[#B59A65] mx-auto max-w-xs" />
        </div>

        {/* Couple's Names in Calligraphy Script */}
        <div className="closing-fade space-y-1">
          <h2 className="font-script text-4xl sm:text-6xl text-[#E9E1D1] font-bold leading-[1.1]">
            {weddingData.groom.name}
          </h2>

          <div className="flex items-center justify-center gap-3 my-1">
            <span className="h-[1px] w-10 bg-[#B59A65]/50" />
            <span className="font-serif italic text-2xl text-[#B59A65] leading-none">&amp;</span>
            <span className="h-[1px] w-10 bg-[#B59A65]/50" />
          </div>

          <h2 className="font-script text-4xl sm:text-6xl text-[#E9E1D1] font-bold leading-[1.1]">
            {weddingData.bride.name}
          </h2>
        </div>

        {/* Confirmed Date */}
        <div className="closing-fade mt-6">
          <span className="editorial-kicker text-xs text-[#B59A65] font-semibold">
            {weddingData.details.day} · {weddingData.details.dateDisplay} · {weddingData.details.time}
          </span>
        </div>

        {/* Presence Quote */}
        <div className="closing-fade mt-4">
          <p className="editorial-quote text-sm sm:text-base text-[#E9E1D1]/90 max-w-md mx-auto leading-[1.6]">
            &ldquo;{weddingData.wording.presenceQuote}&rdquo;
          </p>
        </div>

        {/* Replay or Top Navigation Controls */}
        <div className="closing-fade mt-12 flex flex-wrap items-center justify-center gap-4 editorial-kicker text-xs">
          <button
            onClick={() => {
              onReopenEnvelope();
              scrollToTop();
            }}
            className="px-5 py-2.5 rounded-full border border-[#B59A65]/40 text-[#E9E1D1] hover:bg-[#35432B] transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Mail className="w-3.5 h-3.5 text-[#B59A65]" />
            <span>Replay Envelope</span>
          </button>

          <button
            onClick={scrollToTop}
            className="px-5 py-2.5 rounded-full border border-[#B59A65]/40 text-[#E9E1D1] hover:bg-[#35432B] transition-colors flex items-center gap-2 cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5 text-[#B59A65]" />
            <span>Return to Top</span>
          </button>
        </div>

        {/* Subtle Footer Note */}
        <div className="closing-fade mt-16 pt-8 border-t border-[#B59A65]/20 text-center w-full">
          <p className="editorial-quote text-xs text-[#899477]">
            Designed with love &amp; prayers for the families of Muhammed Jalaludheen &amp; Najah Fathima K
          </p>
        </div>
      </div>
    </footer>
  );
};
