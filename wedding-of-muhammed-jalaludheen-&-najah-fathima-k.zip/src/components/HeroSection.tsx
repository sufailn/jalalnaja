import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { WeddingData } from '../data/weddingConfig';
import { CornerOrnament, MughalArchMotif, OliveBranch, OrnamentalDivider, BackgroundBotanicals } from './FloralDecorations';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  weddingData: WeddingData;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ weddingData }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const archRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Staggered reveal for Hero typography
      gsap.fromTo(
        '.hero-stagger',
        { opacity: 0, y: 35 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          stagger: 0.22,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
          },
        }
      );

      // Subtle parallax on decorative foliage
      gsap.to('.hero-foliage', {
        y: -25,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.2,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative min-h-[92vh] flex flex-col items-center justify-center px-4 py-24 paper-grain overflow-hidden"
    >
      {/* Living Botanical Background Ornaments with GSAP Pulse */}
      <BackgroundBotanicals variant="light" />
      {/* Background Motif inspired by Reference 2 (Vertical Pinstripes with repeating florals) */}
      <div
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          backgroundImage: `repeating-linear-gradient(
            to right,
            transparent,
            transparent 38px,
            rgba(65, 75, 46, 0.12) 38px,
            rgba(65, 75, 46, 0.12) 40px
          )`,
        }}
      />

      {/* Mughal Arch Decorative Floral Border snippet at top & bottom */}
      <div className="absolute top-0 left-0 right-0 h-16 pointer-events-none overflow-hidden opacity-30 flex justify-center">
        <div
          className="w-full h-full bg-repeat-x bg-top"
          style={{
            backgroundImage: `url('/assets/aistudio/WhatsApp_Image_2026-10-31_at_2.30.28_PM__1__ba4c5a9c.jpeg')`,
            backgroundSize: '360px auto',
            backgroundPosition: 'center 75%',
          }}
        />
      </div>

      {/* Main Arch Frame Container */}
      <div
        ref={archRef}
        className="relative z-10 w-full max-w-3xl mx-auto border border-[#B59A65]/40 rounded-t-[140px] sm:rounded-t-[200px] p-8 sm:p-14 md:p-18 bg-[#F4F0E6]/85 backdrop-blur-xs shadow-[0_20px_50px_rgba(65,75,46,0.08)] flex flex-col items-center text-center"
      >
        {/* Inner Arch Hairline Border */}
        <div className="absolute inset-2.5 sm:inset-4 border border-[#414B2E]/20 rounded-t-[130px] sm:rounded-t-[185px] pointer-events-none" />

        {/* Top Corner Filigrees */}
        <CornerOrnament className="absolute -top-3 -left-3 w-10 h-10 text-[#B59A65]" />
        <CornerOrnament className="absolute -top-3 -right-3 w-10 h-10 text-[#B59A65] -scale-x-100" />

        {/* Top Calligraphy Monogram Logo & Arch Motif */}
        <div className="hero-stagger flex flex-col items-center mb-4">
          <div className="w-24 h-32 sm:w-32 sm:h-44 mb-2 flex items-center justify-center">
            <img
              src="/assets/aistudio/logo_cropped_olive.png"
              alt="Jalaludheen & Najah Monogram Logo"
              className="w-full h-full object-contain drop-shadow-xs"
            />
          </div>
          <MughalArchMotif className="w-36 sm:w-44 h-12 sm:h-16 text-[#414B2E] mx-auto opacity-70" />
        </div>

        {/* Family Greeting */}
        <div className="hero-stagger">
          <p className="editorial-kicker text-xs sm:text-sm text-[#414B2E] font-medium mb-2.5">
            Together with their families
          </p>
          <div className="h-[1px] w-14 bg-[#B59A65] mx-auto mb-5" />
        </div>

        {/* Groom & Bride Names */}
        <div ref={textRef} className="my-2 space-y-2">
          {/* Groom */}
          <div className="hero-stagger relative">
            <h1 className="font-script text-4xl sm:text-6xl md:text-7xl text-[#414B2E] tracking-normal leading-[1.1] font-bold drop-shadow-xs">
              {weddingData.groom.name}
            </h1>
          </div>

          {/* Elegant Ampersand with Olive Leaves */}
          <div className="hero-stagger flex items-center justify-center gap-4 my-2">
            <OliveBranch className="hero-foliage w-16 sm:w-24 h-8 text-[#899477] opacity-80" />
            <span className="font-serif italic text-3xl sm:text-4xl text-[#542D3A] font-light leading-none">
              &amp;
            </span>
            <OliveBranch className="hero-foliage w-16 sm:w-24 h-8 text-[#899477] opacity-80" flipped />
          </div>

          {/* Bride */}
          <div className="hero-stagger relative">
            <h1 className="font-script text-4xl sm:text-6xl md:text-7xl text-[#414B2E] tracking-normal leading-[1.1] font-bold drop-shadow-xs">
              {weddingData.bride.name}
            </h1>
          </div>

          {/* Confirmed Date & Time */}
          <div className="hero-stagger pt-3">
            <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full border border-[#B59A65]/40 bg-[#E9E1D1]/60">
              <span className="editorial-kicker text-[11px] sm:text-xs text-[#414B2E] font-semibold tracking-[0.24em]">
                {weddingData.details.day} · {weddingData.details.dateDisplay} · {weddingData.details.time}
              </span>
            </div>
          </div>
        </div>

        {/* Ornamental Divider */}
        <div className="hero-stagger w-full max-w-sm">
          <OrnamentalDivider className="my-6 text-[#B59A65]" />
        </div>

        {/* Subtitle */}
        <div className="hero-stagger max-w-xl">
          <p className="editorial-quote text-base sm:text-xl text-[#37352F]/90 font-normal leading-[1.6]">
            &ldquo;{weddingData.wording.subtitle}&rdquo;
          </p>
        </div>

        {/* Islamic Surah Verse snippet */}
        <div className="hero-stagger mt-8 pt-6 border-t border-[#B59A65]/30 max-w-lg">
          <p className="font-arabic text-xl sm:text-2xl text-[#414B2E] leading-[1.9] mb-2">
            {weddingData.wording.quranVerseArabic}
          </p>
          <p className="editorial-quote text-xs sm:text-sm text-[#37352F]/75 leading-[1.65]">
            &ldquo;{weddingData.wording.quranVerseTranslation}&rdquo;
          </p>
          <p className="editorial-kicker text-[10px] sm:text-[11px] text-[#B59A65] mt-2.5 font-medium tracking-[0.28em]">
            {weddingData.wording.quranVerseReference}
          </p>
        </div>
      </div>
    </section>
  );
};
