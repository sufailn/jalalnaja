import React, { useState, useEffect } from 'react';
import { Clock, Heart } from 'lucide-react';

interface CountdownTimerProps {
  targetDate: string | null;
  targetTime?: string | null;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({
  targetDate,
  targetTime,
}) => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);

  useEffect(() => {
    if (!targetDate) {
      setTimeLeft(null);
      return;
    }

    const calculateTime = () => {
      // Parse ISO or standard date string
      const dateString = targetTime ? `${targetDate} ${targetTime}` : `${targetDate}T12:00:00`;
      const target = new Date(dateString).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (isNaN(difference)) {
        setTimeLeft(null);
        return;
      }

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);

      setTimeLeft({ days, hours, minutes, seconds, isPast: false });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [targetDate, targetTime]);

  if (!targetDate || !timeLeft) {
    return (
      <div className="w-full max-w-lg mx-auto p-6 sm:p-8 bg-[#F4F0E6] rounded border border-[#B59A65]/40 text-center paper-grain shadow-sm">
        <div className="w-10 h-10 rounded-full bg-[#E9E1D1] text-[#414B2E] mx-auto flex items-center justify-center mb-3">
          <Clock className="w-5 h-5 text-[#414B2E]" />
        </div>
        <span className="font-cinzel text-xs tracking-[0.25em] uppercase text-[#899477] font-semibold">
          Save the Date
        </span>
        <h4 className="font-serif text-2xl text-[#414B2E] my-1 font-normal">
          Anticipating the Blessed Day
        </h4>
        <p className="font-serif italic text-xs sm:text-sm text-[#37352F]/75 max-w-xs mx-auto leading-relaxed mt-2">
          The official wedding date will be announced here shortly. We look forward to celebrating with you!
        </p>
      </div>
    );
  }

  if (timeLeft.isPast) {
    return (
      <div className="w-full max-w-lg mx-auto p-6 sm:p-8 bg-[#414B2E] text-[#F4F0E6] rounded border border-[#B59A65]/40 text-center shadow-md">
        <Heart className="w-8 h-8 text-[#B59A65] mx-auto mb-2 fill-current" />
        <h4 className="font-serif text-2xl text-[#F4F0E6] my-1">
          Alhamdulillah, The Blessed Day Has Arrived!
        </h4>
        <p className="font-serif italic text-xs sm:text-sm text-[#E9E1D1]/80 mt-1">
          May Allah grant eternal barakah, harmony, and joy.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-6 sm:p-8 bg-[#F4F0E6] rounded border border-[#B59A65]/40 text-center paper-grain shadow-sm">
      <span className="editorial-kicker text-xs text-[#899477] font-semibold">
        Counting Down to the Beginning
      </span>
      <h4 className="editorial-h2 text-2xl sm:text-3xl text-[#414B2E] mt-1 mb-6 font-normal">
        Until We Say &ldquo;Qubool Hai&rdquo;
      </h4>

      <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-md mx-auto">
        {/* Days */}
        <div className="p-3 sm:p-4 bg-[#E9E1D1] rounded border border-[#B59A65]/30 flex flex-col items-center">
          <span className="editorial-display text-2xl sm:text-4xl text-[#414B2E] font-semibold tabular-nums">
            {String(timeLeft.days).padStart(2, '0')}
          </span>
          <span className="editorial-kicker text-[10px] sm:text-xs text-[#899477] mt-1">
            Days
          </span>
        </div>

        {/* Hours */}
        <div className="p-3 sm:p-4 bg-[#E9E1D1] rounded border border-[#B59A65]/30 flex flex-col items-center">
          <span className="editorial-display text-2xl sm:text-4xl text-[#414B2E] font-semibold tabular-nums">
            {String(timeLeft.hours).padStart(2, '0')}
          </span>
          <span className="editorial-kicker text-[10px] sm:text-xs text-[#899477] mt-1">
            Hours
          </span>
        </div>

        {/* Minutes */}
        <div className="p-3 sm:p-4 bg-[#E9E1D1] rounded border border-[#B59A65]/30 flex flex-col items-center">
          <span className="editorial-display text-2xl sm:text-4xl text-[#414B2E] font-semibold tabular-nums">
            {String(timeLeft.minutes).padStart(2, '0')}
          </span>
          <span className="editorial-kicker text-[10px] sm:text-xs text-[#899477] mt-1">
            Mins
          </span>
        </div>

        {/* Seconds */}
        <div className="p-3 sm:p-4 bg-[#E9E1D1] rounded border border-[#B59A65]/30 flex flex-col items-center">
          <span className="editorial-display text-2xl sm:text-4xl text-[#542D3A] font-semibold tabular-nums">
            {String(timeLeft.seconds).padStart(2, '0')}
          </span>
          <span className="editorial-kicker text-[10px] sm:text-xs text-[#899477] mt-1">
            Secs
          </span>
        </div>
      </div>
    </div>
  );
};
