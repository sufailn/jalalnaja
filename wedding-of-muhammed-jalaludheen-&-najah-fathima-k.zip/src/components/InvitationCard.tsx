import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { WeddingData } from '../data/weddingConfig';
import { CornerOrnament, OliveBranch, OrnamentalDivider, WaxSealEmblem, BackgroundBotanicals } from './FloralDecorations';
import { Calendar, Clock, MapPin, Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface InvitationCardProps {
  weddingData: WeddingData;
  onOpenDetailsModal?: () => void;
}

export const InvitationCard: React.FC<InvitationCardProps> = ({
  weddingData,
  onOpenDetailsModal,
}) => {
  const containerRef = useRef<HTMLElement>(null);
  const mainCardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        mainCardRef.current,
        { opacity: 0, y: 50, scale: 0.96 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 1.3,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top 70%',
          },
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="invitation"
      ref={containerRef}
      className="relative min-h-screen py-24 px-4 bg-[#E9E1D1]/60 paper-grain-cream flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Living Background Botanical Ornaments with Graceful Pulse */}
      <BackgroundBotanicals variant="light" />
      {/* Decorative botanical leaf corner accents */}
      <div className="absolute top-10 left-10 opacity-30 pointer-events-none hidden lg:block">
        <OliveBranch className="w-40 h-20 text-[#899477]" />
      </div>
      <div className="absolute bottom-10 right-10 opacity-30 pointer-events-none hidden lg:block">
        <OliveBranch className="w-40 h-20 text-[#899477]" flipped />
      </div>

      {/* Section Kicker */}
      <div className="text-center mb-10 z-10">
        <span className="editorial-kicker text-xs text-[#414B2E] font-semibold">
          Formal Invitation
        </span>
        <h2 className="editorial-h1 text-3xl sm:text-4xl lg:text-5xl text-[#35432B] font-normal mt-1">
          The Wedding Celebration
        </h2>
        <div className="w-12 h-[1px] bg-[#B59A65] mx-auto mt-3.5" />
      </div>

      {/* Main Suite Composition inspired by Reference 1 */}
      <div className="relative w-full max-w-4xl mx-auto flex flex-col items-center">
        
        {/* Lace Doily Accent Element behind top-right of card */}
        <div className="absolute -top-10 -right-4 sm:-right-8 w-32 sm:w-44 h-32 sm:h-44 rounded-full border-2 border-dashed border-[#B59A65]/35 bg-[#F4F0E6]/90 p-4 shadow-sm flex flex-col items-center justify-center text-center rotate-6 pointer-events-none z-0">
          <div className="w-full h-full rounded-full border border-[#899477]/30 flex flex-col items-center justify-center p-2">
            <span className="font-script text-xl sm:text-2xl text-[#414B2E]">Du&apos;a</span>
            <span className="editorial-quote text-[10px] sm:text-xs text-[#899477] leading-tight mt-0.5">
              Barakallahu lakuma
            </span>
          </div>
        </div>

        {/* Central Printed Invitation Card */}
        <div
          ref={mainCardRef}
          className="relative z-10 w-full max-w-2xl bg-[#F4F0E6] p-8 sm:p-14 md:p-16 shadow-[0_20px_50px_rgba(53,67,43,0.18)] rounded-xs border border-[#B59A65]/40 paper-grain text-center"
        >
          {/* Double-line thin decorative border */}
          <div className="absolute inset-3 sm:inset-5 border border-[#B59A65]/60 pointer-events-none rounded-xs" />
          <div className="absolute inset-4 sm:inset-6 border border-[#414B2E]/15 pointer-events-none rounded-xs" />

          {/* Corner Filigrees */}
          <CornerOrnament className="absolute top-4 left-4 sm:top-6 sm:left-6 w-9 h-9 text-[#B59A65]" />
          <CornerOrnament className="absolute top-4 right-4 sm:top-6 sm:right-6 w-9 h-9 text-[#B59A65] -scale-x-100" />
          <CornerOrnament className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 w-9 h-9 text-[#B59A65] -scale-y-100" />
          <CornerOrnament className="absolute bottom-4 right-4 sm:bottom-6 sm:right-6 w-9 h-9 text-[#B59A65] -scale-100" />

          {/* Couple's Calligraphy Monogram Crest */}
          <div className="pt-2 pb-1 flex justify-center">
            <div className="w-20 h-28 sm:w-28 sm:h-38 flex items-center justify-center">
              <img
                src="/assets/aistudio/logo_cropped_olive.png"
                alt="Bespoke Monogram Logo"
                className="w-full h-full object-contain drop-shadow-xs"
              />
            </div>
          </div>

          {/* Basmala Calligraphy */}
          <div className="pb-2">
            <p className="font-arabic text-2xl sm:text-3xl text-[#414B2E] tracking-wider leading-[1.8]">
              {weddingData.wording.basmala}
            </p>
            <p className="editorial-quote text-xs sm:text-sm text-[#899477] mt-1">
              &ldquo;{weddingData.wording.basmalaTranslation}&rdquo;
            </p>
          </div>

          <div className="my-5">
            <OrnamentalDivider className="text-[#B59A65] mx-auto" />
          </div>

          {/* Formal Preamble */}
          <p className="editorial-subhead text-sm sm:text-base text-[#37352F]/85 max-w-lg mx-auto leading-[1.68]">
            {weddingData.wording.invitationPreamble}
          </p>

          {/* Names in Calligraphy Script */}
          <div className="my-6 space-y-2">
            <h3 className="font-script text-4xl sm:text-5xl md:text-6xl text-[#414B2E] font-bold gold-foil-text leading-[1.1]">
              {weddingData.groom.name}
            </h3>

            <div className="flex items-center justify-center gap-3">
              <span className="h-[1px] w-12 bg-[#B59A65]/50" />
              <span className="font-serif italic text-2xl text-[#542D3A] leading-none">&amp;</span>
              <span className="h-[1px] w-12 bg-[#B59A65]/50" />
            </div>

            <h3 className="font-script text-4xl sm:text-5xl md:text-6xl text-[#414B2E] font-bold gold-foil-text leading-[1.1]">
              {weddingData.bride.name}
            </h3>
          </div>

          {/* Blessing & Presence Request */}
          <p className="editorial-quote text-sm sm:text-base text-[#37352F]/90 max-w-md mx-auto leading-[1.62] mb-6">
            &ldquo;{weddingData.wording.invitationClosing}&rdquo;
          </p>

          {/* Key Event Cards with Confirmed Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6 border-t border-[#B59A65]/30">
            {/* Date / Day */}
            <div className="p-3.5 bg-[#E9E1D1]/60 rounded border border-[#B59A65]/30 text-center flex flex-col items-center justify-center">
              <Calendar className="w-4 h-4 text-[#414B2E] mb-1" />
              <span className="editorial-kicker text-[10px] text-[#899477] font-semibold">Date</span>
              <span className="editorial-h3 text-xs sm:text-sm font-medium text-[#414B2E] mt-0.5">
                {weddingData.details.dateDisplay}
              </span>
              <span className="editorial-quote text-[11px] text-[#542D3A]">
                {weddingData.details.day}
              </span>
            </div>

            {/* Time */}
            <div className="p-3.5 bg-[#E9E1D1]/60 rounded border border-[#B59A65]/30 text-center flex flex-col items-center justify-center">
              <Clock className="w-4 h-4 text-[#414B2E] mb-1" />
              <span className="editorial-kicker text-[10px] text-[#899477] font-semibold">Time</span>
              <span className="editorial-h3 text-xs sm:text-sm font-medium text-[#414B2E] mt-0.5">
                {weddingData.details.time}
              </span>
              <span className="editorial-quote text-[11px] text-[#542D3A]">
                Auspicious Hour
              </span>
            </div>

            {/* Venue & Google Maps */}
            <a
              href={weddingData.details.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 bg-[#E9E1D1]/60 hover:bg-[#E9E1D1] transition-colors rounded border border-[#B59A65]/30 text-center flex flex-col items-center justify-center group cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-[#542D3A] mb-1 group-hover:scale-110 transition-transform" />
              <span className="editorial-kicker text-[10px] text-[#899477] font-semibold">Location</span>
              <span className="editorial-h3 text-xs sm:text-sm font-medium text-[#414B2E] mt-0.5 group-hover:underline">
                View on Google Maps
              </span>
              <span className="editorial-kicker text-[9px] text-[#B59A65] mt-0.5">
                Tap for Directions &rarr;
              </span>
            </a>
          </div>
        </div>

        {/* Companion Burgundy Stationery Card */}
        <div className="mt-8 sm:-mt-8 sm:self-end sm:mr-4 z-20 w-full sm:w-72 bg-[#542D3A] text-[#F4F0E6] p-6 rounded shadow-xl border border-[#B59A65]/40 transition-transform hover:-translate-y-1 duration-300">
          <div className="border border-[#F4F0E6]/20 p-4 rounded-xs text-center">
            <span className="editorial-kicker text-[10px] text-[#B59A65] font-semibold">
              Celebration Note
            </span>
            <h4 className="font-script text-2xl text-[#F4F0E6] my-1 leading-tight">
              Prayers &amp; Blessings
            </h4>
            <p className="editorial-quote text-xs text-[#E9E1D1]/90 leading-[1.65] mt-2">
              &ldquo;May Allah bless this union and grant abundance in peace, health, and endless barakah.&rdquo;
            </p>
            <div className="mt-4 pt-3 border-t border-[#F4F0E6]/15 flex items-center justify-center gap-2 editorial-kicker text-[10px] text-[#B59A65]">
              <Heart className="w-3 h-3 fill-current" />
              <span>With Sincere Du&apos;as</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
