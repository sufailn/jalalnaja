import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CornerOrnament, MughalArchMotif, OliveBranch, OrnamentalDivider } from './FloralDecorations';
import { Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface LovedOnesProps {
  sisters: string[];
}

export const LovedOnes: React.FC<LovedOnesProps> = ({ sisters }) => {
  const containerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.sister-card',
        { opacity: 0, y: 25 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.18,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top 80%',
          },
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="loved-ones"
      ref={containerRef}
      className="relative py-24 px-4 bg-[#E9E1D1]/40 paper-grain-cream border-t border-b border-[#B59A65]/30 overflow-hidden"
    >
      <div className="max-w-4xl mx-auto text-center relative z-10">
        
        {/* Subtle Decorative Arch */}
        <MughalArchMotif className="w-32 h-14 text-[#899477] mx-auto opacity-75 mb-3" />

        <span className="editorial-kicker text-xs text-[#414B2E] font-semibold">
          Bride&apos;s Cherished Circle
        </span>
        <h2 className="editorial-h1 text-3xl sm:text-4xl text-[#35432B] mt-1 font-normal">
          The Bride&apos;s Beloved Sisters
        </h2>
        <div className="w-12 h-[1px] bg-[#B59A65] mx-auto mt-3.5 mb-6" />

        <p className="editorial-quote text-sm sm:text-base text-[#37352F]/80 max-w-lg mx-auto mb-12">
          Surrounded by the constant companionship, heartfelt prayers, and joyful love of her dearest sisters.
        </p>

        {/* 4 Sisters Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {sisters.map((name) => (
            <div
              key={name}
              className="sister-card bg-[#F4F0E6] p-6 sm:p-8 rounded-sm border border-[#B59A65]/35 shadow-xs flex flex-col items-center justify-center text-center relative group hover:border-[#414B2E] transition-all duration-300"
            >
              {/* Corner embellishment */}
              <CornerOrnament className="absolute top-2 left-2 w-5 h-5 text-[#B59A65]/50 group-hover:text-[#B59A65] transition-colors" />
              <CornerOrnament className="absolute bottom-2 right-2 w-5 h-5 text-[#B59A65]/50 group-hover:text-[#B59A65] transition-colors -scale-100" />

              <div className="w-8 h-8 rounded-full bg-[#E9E1D1] text-[#542D3A] flex items-center justify-center mb-3">
                <Heart className="w-3.5 h-3.5 fill-current" />
              </div>

              <span className="editorial-kicker text-[10px] text-[#899477] mb-1.5">
                Sister
              </span>

              <h3 className="font-script text-2xl sm:text-3xl text-[#414B2E] font-bold group-hover:text-[#35432B] transition-colors leading-tight">
                {name}
              </h3>
            </div>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <OrnamentalDivider className="text-[#B59A65]/70 max-w-xs" />
        </div>
      </div>
    </section>
  );
};
